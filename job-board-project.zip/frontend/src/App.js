
function App() {
  return <h1>Job Board Frontend</h1>;
}
export default App;
