
const express = require("express");
const app = express();
app.use(express.json());
app.get("/", (req,res)=>res.send("Job Board Backend Running"));
app.listen(5000, ()=>console.log("Server running on 5000"));
